#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <signal.h>

#define MAX_NAME 32
#define MAX_MSG 500
#define PORT  5555
#define BUFFER_SIZE 500

volatile sig_atomic_t flag=0;
int sockfd;

struct sockaddr_in serverAddr;

char name[MAX_NAME];

void error(char *msg){
  perror(msg);
  exit(1);
}

void *readmsg(){
  char msg[MAX_MSG];

  while(1){
    bzero(msg, MAX_MSG);
    int n=recv(sockfd, msg, MAX_MSG, 0);
    if(n<0)
      error("[-] Error in receiving \n");

    msg[strlen(msg)-1]='\0';

    printf("%s \n", msg);  
    fflush(stdout);
    bzero(msg, MAX_MSG);
  }
}


void * writemsg(){
  char msg[MAX_MSG];
    char final[1000];
  while(1){
    bzero(msg, MAX_MSG);
    printf("\r %s : " , name);
    fflush(stdout);
    fflush(stdin);
    fgets(msg, MAX_MSG, stdin);
    msg[strlen(msg)]='\0';


    if((strncmp(msg, "bye", 3))==0){
      printf("[-] Exiting ip: %s port :%d\n", inet_ntoa(serverAddr.sin_addr), ntohs(serverAddr.sin_port));
      send(sockfd, msg, strlen(msg), 0);
      close(sockfd);
      break;
    }
      sprintf(final, "%s : %s", name, msg);
      send(sockfd, final, strlen(final), 0);
      bzero(msg, MAX_MSG);
  }
}

void cntrlC(int sig){
  flag=1;
}

int main(){

  
  sockfd= socket(AF_INET, SOCK_STREAM, 0);
  if(sockfd<0)
    error("[-] Socket creation failed \n");

  signal(SIGINT, cntrlC);


  printf("Enter Name: ");
  fgets(name, MAX_NAME, stdin);
  name[strlen(name)-1]='\0';

  bzero((char *)&serverAddr, sizeof(serverAddr));

  serverAddr.sin_family=AF_INET;
  serverAddr.sin_port=htons(PORT);
  serverAddr.sin_addr.s_addr=inet_addr("127.0.0.1");

  if(connect(sockfd, (struct sockaddr *)&serverAddr, sizeof(serverAddr))<0)
    error("[-] Connection failed \n");

  // printf("Password : ");
  // char password[100];
  // scanf("%s", password);
  // send(sockfd, password, strlen(password), 0);
  // fflush(stdin);
  // fflush(stdout);
  send(sockfd, name, strlen(name), 0);
  printf("======CHATROOM LIVE======\n");

  pthread_t read_t, write_t;

  pthread_create(&write_t, NULL, &writemsg, NULL);
  pthread_create(&read_t, NULL, &readmsg, NULL);

  while(1){
    if(flag){
      printf("[-] Exiting ip: %s port :%d\n", inet_ntoa(serverAddr.sin_addr), ntohs(serverAddr.sin_port));
      close(sockfd);
      break;
    }  
  }
  return 0;
}