#include <stdio.h>
#include <stdlib.h>

int main()
{
    char command[100] = "dir"; // Replace with your desired command

    int status = system(command);
    if (status == -1) {
        perror("system failed");
        return 1;
    } else {
        printf("Command executed with status %d\n", status);
        return 0;
    }
}
