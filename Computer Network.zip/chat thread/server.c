#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <signal.h>

#define MAX_CLIENTS 5
#define BUFFERSIZE  1024
#define MAX_NAME 32
#define PORT  5555

static _Atomic unsigned int clientCount=0;
static int uid=0;



typedef struct{
  struct sockaddr_in address;
  int sockfd;
  int uid;
  char name[MAX_NAME];
}client_t;

client_t *clients[MAX_CLIENTS];

pthread_mutex_t Mutex=PTHREAD_MUTEX_INITIALIZER;


void error(char *msg){
  perror(msg);
  exit(1);
}

void queueClient(client_t *cl){
  pthread_mutex_lock(&Mutex);

  for(int i=0; i<MAX_CLIENTS; i++){
    if(!clients[i]){
      clients[i]=cl;
      break;
    }
  }
  pthread_mutex_unlock(&Mutex);
}

void removeClient(int uid){
  pthread_mutex_lock(&Mutex);
  
  for(int i=0; i<MAX_CLIENTS; i++){
    if(clients[i]){
      if(clients[i]->uid==uid){
        free(clients[i]);
        clients[i]=NULL;
        break;
      }
    }
  }
  pthread_mutex_unlock(&Mutex);
}

void sendMsg(char *s, int uid){
  pthread_mutex_lock(&Mutex);

  for(int i=0; i<MAX_CLIENTS; i++){
    if(clients[i]){
      if(clients[i]->uid!=uid){
        if(write(clients[i]->sockfd, s, strlen(s))<0){
          perror("[-] Error in sending message \n");
          break;
        }
      }
    }
  }

  pthread_mutex_unlock(&Mutex);
}

void * handleClient(void *arg){
  char buffer[BUFFERSIZE];
  char name[MAX_NAME];
  int leaveFlag=0;

  clientCount++;
  client_t *cli=(client_t *)arg;



  int n=recv(cli->sockfd, name, MAX_NAME, 0);
  if(n<0){
    perror("[-] Error in receiving name \n");
  }

  name[n]='\0';
  
  strcpy(cli->name, name);
  bzero(buffer, BUFFERSIZE);
  sprintf(buffer, "%s has joined \n", cli->name);
  sendMsg(buffer, cli->uid);
  printf("%s has joined \n", cli->name);

  while(1){
    if(leaveFlag)
      break;
    
    bzero(buffer, BUFFERSIZE);

    fflush(stdout);
    fflush(stdin);

    int n=recv(cli->sockfd, buffer, BUFFERSIZE, 0);
    buffer[n]='\0';
    if(n<0){
      error("[-] Error in receiving message \n");
    }
    if(strncmp(buffer,"bye",3)==0){
      leaveFlag=1;
      printf("\r%s has left \n", cli->name);
      sprintf(buffer, "%s has left \n", cli->name);
      sendMsg(buffer, cli->uid);
    }

    fflush(stdout);
    // sprintf(buffer, "%s: %s", cli->name, buffer);
    sendMsg(buffer, cli->uid);
    printf("%s \n", buffer);
    }

    close(cli->sockfd);
    removeClient(cli->uid);
    free(cli);
    clientCount--;
    pthread_detach(pthread_self());
    return NULL;
}


int main(){

  int sockfd;
  struct sockaddr_in serverAddr, clientAddr;
  char name[MAX_NAME];

  sockfd=socket(AF_INET, SOCK_STREAM, 0);
  if(sockfd<0)
    error("[-] Error in connection \n");

  serverAddr.sin_family=AF_INET;
  serverAddr.sin_port=htons(PORT);
  serverAddr.sin_addr.s_addr=inet_addr("127.0.0.1");

//signal is used to set the disposition of the signal signum to handler. The signal handler is a 
//function that is called when the signal is raised. The signal handler is set to SIG_IGN to ignore the signal.
  signal(SIGPIPE, SIG_IGN);
//setsockopt is used to set the socket options for the socket referred to by the file descriptor sockfd ,
 //at the protocol level specified by level and the option name specified by optname. The option value is
 // pointed to by optval and the option length is specified by optlen. 
//The setsockopt() function returns 0 on success and -1 on failure.
//SO_REUSEADDR is used to allow the local address to be reused when the server is restarted before the required wait time expires.
//SOL_SOCKET is the socket layer itself.
  if(setsockopt(sockfd, SOL_SOCKET,( SO_REUSEADDR|SO_REUSEADDR ), &(int){1}, sizeof(int))<0)
    error("[-] Error in setting socket options \n");


  int bindstatus= bind(sockfd, (struct sockaddr*)&serverAddr, sizeof(serverAddr));
  if(bindstatus<0)
    error("[-] Error in binding \n");

  int listenstatus=listen(sockfd, MAX_CLIENTS);
  if(listenstatus<0)
    error("[-] Error in listening \n");

  socklen_t clientLen=sizeof(clientAddr);

printf("======CHATROOM LIVE======\n");

  while(1){
    int clientfd=accept(sockfd, (struct sockaddr*)&clientAddr, &clientLen);
    if(clientfd<0)
      error("[-] Error in accepting \n");

    printf("New client connected from %s:%d \n" , inet_ntoa(clientAddr.sin_addr), ntohs(clientAddr.sin_port));

    if(clientCount+1==MAX_CLIENTS){
      printf("[-] Max clients reached. Rejected: ");
      close(clientfd);
      continue;
    }
    
    client_t *cli=(client_t*)malloc(sizeof(client_t));
    cli->address=clientAddr;
    cli->sockfd=clientfd;
    cli->uid=uid++;

    queueClient(cli);
    pthread_t thread;
    if(pthread_create(&thread, NULL, &handleClient, (void*)cli)!=0)
      printf("[-] Error in creating thread \n");

    sleep(1);
}

  return 0;
}
