#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <pthread.h>
#include <signal.h>
#include <arpa/inet.h>



#define MAX_CLIENTS 5
#define BUFFER_SIZE 1024
#define NAME_SIZE 32
#define PORT 5555


typedef struct{
  struct sockaddr_in address;
  int sockfd;
  int ID;
  char name[NAME_SIZE];
} client_type;

client_type *clients[MAX_CLIENTS];

static _Atomic unsigned int clientCount = 0;
static _Atomic unsigned int terminator = 0;
static int cid = 0;

void error(char *msg){
  perror(msg);
  exit(1);
}

int sockfd;;

pthread_mutex_t Mutex = PTHREAD_MUTEX_INITIALIZER;

void pushclient(client_type *cl){
  pthread_mutex_lock(&Mutex);

  for(int i=0; i<MAX_CLIENTS; i++){
    if(!clients[i]){
      clients[i]=cl;
      break;
    }
  }

  pthread_mutex_unlock(&Mutex);
}

void removeclient(int id){
  pthread_mutex_lock(&Mutex);

  for(int i=0;i<MAX_CLIENTS;i++){
    if(clients[i]){
      if(clients[i]->ID==id){
        free(clients[i]);
        clients[i]=NULL;
        break;
      }
    }
  }
  pthread_mutex_unlock(&Mutex);
}

void sendexcept(int cid, char *s,int len){
pthread_mutex_lock(&Mutex);
  for(int i=0;i<MAX_CLIENTS;i++){
    if(clients[i]){
      if(clients[i]->ID!=cid){
        if(write(clients[i]->sockfd, s, len)<0){
          error("[-]ERROR writing to socket");
        }
      }
    }
  }
pthread_mutex_unlock(&Mutex);
}


void * responding_client(void * cli){

  char buffer[BUFFER_SIZE];
  char name[NAME_SIZE];
  volatile sig_atomic_t leaveFlag=0;

  clientCount++;

  client_type *client=(client_type*)cli;

  int n=recv(client->sockfd, name, NAME_SIZE, 0);
  // if(n<0 || strlen(name)<2 || strlen(name)>=NAME_SIZE-1)
  //   leaveFlag=1;
  
  name[n]='\0';

  fflush(stdout);
  fflush(stdin);

  strcpy(client->name, name);
  printf("%s has slide in to chat. \n", client->name);
  sprintf(buffer, "\n %s has slide in to chat. \n", client->name);
  sendexcept(client->ID, buffer,strlen(buffer));

  while(!leaveFlag){

 
    bzero(buffer, BUFFER_SIZE);

    fflush(stdout);
    fflush(stdin);

    n=recv(client->sockfd,buffer, BUFFER_SIZE, 0);
    if(n<0){
      error("[-]ERROR reading from socket");
    }

    // buffer[strlen(buffer)]='\0';

    if(strstr(buffer, "/bye")!=0 || strstr(buffer, "/exit")!=0 || strstr(buffer, "/quit")!=0){
      leaveFlag=1;
      sprintf(buffer, "%s has left ", client->name);
      printf("\n %s \n", buffer);
      sendexcept(client->ID, buffer,strlen(buffer));
      break;
    }

    else{
      fflush(stdout);
      // sendexcept(client->ID, buffer, strlen(bu


        char recvname[NAME_SIZE];
        int i;
        for( i=0;buffer[i]!=':';i++){
          recvname[i]=buffer[i];
        }
        recvname[i++]='\0';

      char * endptr;
      int a=strtol(buffer+i,&endptr,10);
      
      printf("%d this is a", a);
      int op;
      int b;
      endptr++;
      
          if(*endptr=='+' )
              op=0;
          else if(*endptr=='-')
              op=1;
          else if(*endptr=='*')
              op=2;
          else if(*endptr=='/')
              op=3;
          
        
        b=atoi(endptr+1);

        //  printf("%d<=a %d<=b %d<=op ", a,b ,op);

        char ans[10];

        switch(op){
          case 0:
            sprintf(ans,"%d",a+b);
            break;
          case 1:
            sprintf(ans,"%d",a-b);
            break;
          case 2:
            sprintf(ans,"%d",a*b);
            break;
          case 3:
            sprintf(ans,"%d",a/b);
            break;
        }
        char msg[BUFFER_SIZE+NAME_SIZE+30];
        sprintf(msg, "%s: %s = %s\n",recvname, buffer, ans);
        printf("%s", msg);
      //  printf("\r%s \n", recvname);
      //  printf("\r%s \n", buffer);
    }
  }

  if(terminator==1)
    return NULL;


  close(client->sockfd);
  removeclient(client->ID);
  clientCount--;
  pthread_detach(pthread_self());
  return NULL;
}


int main(){

  
  struct sockaddr_in serveraddr,clientaddr;

  sockfd=socket(AF_INET, SOCK_STREAM, 0);
  if(sockfd<0){
    error("[-]ERROR opening socket");
  }

  signal(SIGPIPE, SIG_IGN);

  if(setsockopt(sockfd, SOL_SOCKET,( SO_REUSEADDR|SO_REUSEADDR ), &(int){1}, sizeof(int))<0)
    error("[-]ERROR setting socket options");

  serveraddr.sin_port=htons(PORT);
  serveraddr.sin_family=AF_INET;
  serveraddr.sin_addr.s_addr=inet_addr("127.0.0.1");


  if(bind(sockfd, (struct sockaddr*)&serveraddr, sizeof(serveraddr))<0){
    error("[-]ERROR binding socket");
  }

  if(listen(sockfd, MAX_CLIENTS)<0){
    error("[-]ERROR listening");
  }

  socklen_t client_len=sizeof(clientaddr);


printf("\r======CHATROOM LIVE======\n");

  while(1){
    
    if(terminator){
      break;
    }

    int clientfd=accept(sockfd, (struct sockaddr*)&clientaddr, &client_len);
    if(clientfd<0){
      error("[-]ERROR accepting connection");
    }
    
    printf("New client connected from %s : %d ", inet_ntoa(clientaddr.sin_addr), ntohs(clientaddr.sin_port));

    if(clientCount+1==MAX_CLIENTS){
      printf("[-]Max clients reached. Rejected: ");
      close(clientfd);
      continue;
    }

    client_type *client=(client_type*)malloc(sizeof(client_type));
    client->address=clientaddr;
    client->sockfd=clientfd;
    client->ID=cid++;

    pushclient(client);
    pthread_t th;

    if(pthread_create(&th, NULL, &responding_client, (void*)client)<0){
      error("[-]ERROR creating thread");
    }
  }

close(sockfd);

return 0;
}


//setsockopt is used to  set the socket options for the socket referred to by the file descriptor sockfd.
//SO_REUSEADDR is used to allow the local address to be reused when the server is restarted before the required wait time expires.

