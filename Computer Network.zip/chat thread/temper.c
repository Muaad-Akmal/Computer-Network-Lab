#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <pthread.h>
#include <sys/types.h>

#define MAX_nodeS 10
#define MAX_LENGTH 2048
#define NAME_LENGTH 15
#define IP "0.0.0.0"
#define PORT "6969"

static int node_count = 0;
int ID = 100;

typedef struct
{
    struct sockaddr_in node_address;
    int node_socket;
    int ID;
    char node_name[NAME_LENGTH];
} node_structure;

node_structure *nodes[MAX_nodeS];
pthread_mutex_t nodes_mutex = PTHREAD_MUTEX_INITIALIZER;
int server_socket = 0;
int server_stop = 0;

void addnode(node_structure *cl)
{
    pthread_mutex_lock(&nodes_mutex);

    for (int i = 0; i < MAX_nodeS; ++i)
        if (!nodes[i])
        {
            nodes[i] = cl;
            break;
        }

    pthread_mutex_unlock(&nodes_mutex);
}

void removenode(int ID)
{
    pthread_mutex_lock(&nodes_mutex);

    for (int i = 0; i < MAX_nodeS; ++i)
        if (nodes[i] && nodes[i]->ID == ID)
        {
            nodes[i] = NULL;
            break;
        }

    pthread_mutex_unlock(&nodes_mutex);
}

void sendMessage(char *node_message, int ID)
{
    pthread_mutex_lock(&nodes_mutex);

    for (int i = 0; i < MAX_nodeS; ++i)
        if (nodes[i] && nodes[i]->ID == ID)
        {
            if (write(nodes[i]->node_socket, node_message, strlen(node_message)) < 0)
            {
                perror("ERROR: write to descriptor failed");
                break;
            }
        }

    pthread_mutex_unlock(&nodes_mutex);
}

void *handlenode(void *node_p)
{
    char node_message[MAX_LENGTH];
    char temp_message[MAX_LENGTH];
    char node_name[NAME_LENGTH];
    int abort = 0;

    node_structure *node = (node_structure *)node_p;

    // if (recv(node->node_socket, node_name, NAME_LENGTH, 0) <= 0)
    // {
    //     abort = 1;
    // }
    // else
    // {

    // getting the ip from node->node_address
    char ip[100];
    ip = inet_ntoa(node->node_address.sin_addr);
    printf("IP : %s \n", ip);
    
    

    strcpy(node->node_name, ip);
    sprintf(node_message, "[+]%s has joined\n", node->node_name);
    printf("%s", node_message);
    //     sendMessage(node_message, node->ID);
    // }

    bzero(node_message, MAX_LENGTH);

    int ID[1] = node->;
    send(node->node_socket, ID, sizeof(int) * 1, 0); // send ID to the nod

    node_count -= 1;
    close(node->node_socket);

    removenode(node->ID);
    free(node);

    pthread_detach(pthread_self());
    return NULL;
}

int main()
{

    int node_socket = 0;
    pthread_t thread_id;

    server_socket = socket(AF_INET, SOCK_STREAM, 0);

    struct sockaddr_in server_address, node_address;
    server_address.sin_family = AF_INET;
    // server_address.sin_addr.s_addr = inet_addr(IP);
    server_address.sin_addr.s_addr = INADDR_ANY;
    server_address.sin_port = htons(atoi(PORT));
    /* Bind */
    if (bind(server_socket, (struct sockaddr *)&server_address, sizeof(server_address)) < 0)
    {
        perror("ERROR: Socket binding failed!");
        return 0;
    }

    if (listen(server_socket, MAX_nodeS) < 0)
    {
        perror("ERROR: Socket listening failed!");
        return 0;
    }

    printf("######## Chat ########\n");

    while (1)
    {
        if (server_stop)
        {
            pthread_exit(thread_id);
            break;
        }

        socklen_t node_address_length = sizeof(node_address);
        node_socket = accept(server_socket, (struct sockaddr *)&node_address, &node_address_length);

        if ((node_count + 1) == MAX_nodeS)
        {
            close(node_socket);
            continue;
        }

        node_structure *node = (node_structure *)malloc(sizeof(node_structure));
        node->node_address = node_address;
        node->node_socket = node_socket;
        node->ID = ID++;

        node_count += 1;
        addnode(node);
        pthread_create(&thread_id, NULL, &handlenode, (void *)node);

        sleep(1);
    }
    close(server_socket);
    printf("Server Shutting Down!\n");
    return 1;
}