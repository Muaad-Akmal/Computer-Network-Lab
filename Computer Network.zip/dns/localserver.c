#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <pthread.h>
#include <signal.h>

#define PORT 4545
#define ROOT_PORT 5555
#define BUFFER_SIZE 100
#define IP_SIZE INET_ADDRSTRLEN
#define URL_SIZE 100
#define DNS_RECORD_SIZE 10
#define MAX_CLIENTS 10


typedef struct{
  char url[URL_SIZE];
  char ip[IP_SIZE];
} dns_t;

typedef struct{
  struct sockaddr_in address;
  char buffer[BUFFER_SIZE];
} args;

static _Atomic unsigned int clientCount = 0;

pthread_mutex_t Mutex = PTHREAD_MUTEX_INITIALIZER;

dns_t* dns[DNS_RECORD_SIZE];


char * search(char *url){
  char *ans=NULL;
  pthread_mutex_lock(&Mutex);
  for (int i = 0; i < DNS_RECORD_SIZE; i++)
  {
    if (dns[i]!=NULL)
      if (strcmp(dns[i]->url, url) == 0)
        {ans= dns[i]->ip;
        break;}
  }
  pthread_mutex_unlock(&Mutex);
  return ans;
}

void pushdns(dns_t *dnsrecord){

  pthread_mutex_lock(&Mutex);
  for (int i = 0; i < DNS_RECORD_SIZE; i++)
  {
    if (!dns[i])
    {
      dns[i] = dnsrecord;
      break;
    }
  }
  pthread_mutex_unlock(&Mutex);
}

void error(char *msg){
  perror(msg);
  exit(1);
}

int sockfd;

void * handler( void * arg ){

  
   args *data= ( args *) arg;

  data->buffer[strlen(data->buffer)]='\0';

  printf("Received URL -> %s\n ", data->buffer);
  

  socklen_t clientlen = sizeof(data->address);
  int n;

  char *ip = search(data->buffer);

  if(ip!=NULL){
    
    printf("Found IP: %s for URL: %s\n", ip, data->buffer);
    printf("Authorized IP sent to client\n");

    struct sockaddr_in addr;
    addr.sin_port=htons(3535);
    addr.sin_family=AF_INET;
    addr.sin_addr.s_addr=inet_addr("127.0.0.1");

    int x=sendto(sockfd, ip, strlen(ip), 0, (struct sockaddr *)&addr, sizeof(addr));
    if (x<0)
      error("[-] Error on Authenticating\n");
    

    int n=sendto(sockfd, ip, strlen(ip), 0, (struct sockaddr *)& data->address, clientlen);
    if (n < 0)
      error("[-] Error on sending\n");

  }else{

    char ipstr[50];

    //call higher DNS server;
    printf("Fetching from higher DNS server\n");
    
    struct sockaddr_in serveraddr;
    serveraddr.sin_port=htons(ROOT_PORT);
    serveraddr.sin_family=AF_INET;
    serveraddr.sin_addr.s_addr=inet_addr("127.0.0.1");
    bind(sockfd, (struct sockaddr*)&serveraddr, sizeof(serveraddr));
    socklen_t serverlen = sizeof(serveraddr);

    int n=sendto(sockfd, data->buffer, strlen(data->buffer), 0, (struct sockaddr *)&serveraddr,serverlen);
    if (n<0)
      error("[-] Error on sending\n");
    
    n=recvfrom(sockfd,ipstr,50, 0,  (struct sockaddr *)&serveraddr, &serverlen);
    printf("Received IP: %s for URL: %s\n", data->buffer, data->buffer);
    //pushdns(dnsrecord);

      dns_t *dnsrecord = malloc(sizeof(dns_t));
      strcpy(dnsrecord->url, data->buffer);
      strcpy(dnsrecord->ip, ipstr);
      pushdns(dnsrecord);

    ipstr[strlen(ipstr)]='\0';
    n=sendto(sockfd, ipstr, strlen(ipstr), 0, (struct sockaddr *)& data->address, clientlen);
    
  }
  pthread_detach(pthread_self());
}



int main(){

  
  struct sockaddr_in serveraddr, clientaddr;


  sockfd = socket(AF_INET, SOCK_DGRAM, 0);
  if (sockfd < 0)
    error("Error opening socket");

  serveraddr.sin_port=htons(PORT);
  serveraddr.sin_family=AF_INET;
  serveraddr.sin_addr.s_addr=INADDR_ANY;

  if (bind(sockfd, (struct sockaddr*)&serveraddr, sizeof(serveraddr)) < 0)
    error("Error on binding");


//remove this later

  dns[0]= malloc(sizeof(dns_t));
  strcpy(dns[0]->url, "www.google.com");
  strcpy(dns[0]->ip, "10.0.0.1");


///

char buffer[BUFFER_SIZE];

printf("Local DNS Server Running\n");
int n;

 while (1){

    socklen_t clientlen = sizeof(clientaddr);

  while ((n = recvfrom(sockfd, buffer, BUFFER_SIZE, 0, (struct sockaddr*)&clientaddr, &clientlen)) < 0) {
  }

  buffer[strlen(buffer)]='\0';

  args *arg = malloc(sizeof(args));
  strcpy(arg->buffer , buffer);
  arg->address = clientaddr;


  clientCount++;

  if (clientCount + 1 == MAX_CLIENTS) {
    printf("Max clients reached. Waiting for others to finish...\n");
    break;
  }

  pthread_t th;
  pthread_create(&th, NULL, &handler, arg);
  sleep(1);
}
  
// close(sockfd);

  return 0;
}
