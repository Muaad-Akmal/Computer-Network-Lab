#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <pthread.h>
#include <signal.h>

#define BUFFER_SIZE 100
#define PORT 4545

void error(char *msg){
  perror(msg);
  exit(1);
}

int main(int argc, char * argv[]){

  if(argc<2){
    perror("[-] Error: No URL provided");
  }

  int sockfd;
  struct sockaddr_in serveraddr;

  sockfd = socket(AF_INET, SOCK_DGRAM, 0);

  serveraddr.sin_family = AF_INET;
  serveraddr.sin_port = htons(PORT);
  serveraddr.sin_addr.s_addr = inet_addr("127.0.0.1");

  socklen_t servlen=sizeof(serveraddr);

  char buffer[BUFFER_SIZE];
  int n;


  n=sendto(sockfd, argv[1], strlen(argv[1]),0, (struct sockaddr *) &serveraddr, servlen );
  if (n < 0) 
      error("[-] ERROR writing to socket\n");

      
  n = recvfrom(sockfd,buffer, 255,0, NULL, NULL );
  if (n < 0) 
      error("[-] ERROR reading from socket\n");
  
  buffer[n]='\0';

  printf("Received message from server: %s \n", buffer);

close(sockfd);



}



