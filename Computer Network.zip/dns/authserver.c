#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <pthread.h>

#define PORT 3535
#define BUFFER_SIZE 100
#define IP_SIZE INET_ADDRSTRLEN
#define URL_SIZE 100
#define DNS_RECORD_SIZE 10
#define MAX_CLIENTS 10


typedef struct{
  char url[URL_SIZE];
  char ip[IP_SIZE];
} dns_t;

typedef struct{
  struct sockaddr_in address;
  char buffer[BUFFER_SIZE];
} args;

static _Atomic unsigned int clientCount = 0;

pthread_mutex_t Mutex = PTHREAD_MUTEX_INITIALIZER;

dns_t* dns[DNS_RECORD_SIZE];


char * search(char *url){
  char *ans=NULL;
  pthread_mutex_lock(&Mutex);
  for (int i = 0; i < DNS_RECORD_SIZE; i++)
  {
    if (dns[i]!=NULL)
      if (strcmp(dns[i]->url, url) == 0)
        {ans= dns[i]->ip;
        break;}
  }
  pthread_mutex_unlock(&Mutex);
  return ans;
}

void pushdns(dns_t *dnsrecord){

  pthread_mutex_lock(&Mutex);
  for (int i = 0; i < DNS_RECORD_SIZE; i++)
  {
    if (!dns[i])
    {
      dns[i] = dnsrecord;
      break;
    }
  }
  pthread_mutex_unlock(&Mutex);
}

void error(char *msg){
  perror(msg);
  exit(1);
}

int sockfd;

void * handler( void * arg ){

  
   args *data= ( args *) arg;

  printf("Received URL -> %s\n ", data->buffer);
  
  socklen_t clientlen = sizeof(data->address);

    printf("Authenticated ip -> %s\n", data->buffer);

  pthread_detach(pthread_self());
}



int main(){

  
  struct sockaddr_in serveraddr, clientaddr;


  sockfd = socket(AF_INET, SOCK_DGRAM, 0);
  if (sockfd < 0)
    error("Error opening socket");

  serveraddr.sin_port=htons(PORT);
  serveraddr.sin_family=AF_INET;
  serveraddr.sin_addr.s_addr=INADDR_ANY;

  if (bind(sockfd, (struct sockaddr*)&serveraddr, sizeof(serveraddr)) < 0)
    error("Error on binding");




char buffer[BUFFER_SIZE];

printf("auth Server Running\n");
int n;

 while (1){

    socklen_t clientlen = sizeof(clientaddr);

  while ((n = recvfrom(sockfd, buffer, BUFFER_SIZE, 0, (struct sockaddr*)&clientaddr, &clientlen)) < 0) {
  }

  buffer[strlen(buffer)]='\0';

  args *arg = malloc(sizeof(args));
  strcpy(arg->buffer , buffer);
  arg->address = clientaddr;


  clientCount++;

  if (clientCount + 1 == MAX_CLIENTS) {
    printf("Max clients reached. Waiting for others to finish...\n");
    break;
  }

  pthread_t th;
  pthread_create(&th, NULL, &handler, arg);
  sleep(1);
}
  
close(sockfd);

  return 0;
}
