#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <pthread.h>
#include <signal.h>

#define PORT 5555
#define BUFFER_SIZE 100
#define IP_SIZE INET_ADDRSTRLEN
#define URL_SIZE 100
#define DNS_RECORD_SIZE 10
#define MAX_CLIENTS 10
#define COM_PORT 9898
#define ORG_PORT 7878

typedef struct{
  char url[URL_SIZE];
  char ip[IP_SIZE];
} dns_t;

typedef struct{
  struct sockaddr_in address;
  char buffer[BUFFER_SIZE];
} args;

static _Atomic unsigned int clientCount = 0;

pthread_mutex_t Mutex = PTHREAD_MUTEX_INITIALIZER;

dns_t* dns[DNS_RECORD_SIZE];


char * search(char *url){
  char *ans=NULL;
  pthread_mutex_lock(&Mutex);
  for (int i = 0; i < DNS_RECORD_SIZE; i++)
  {
    if (dns[i]!=NULL)
      if (strcmp(dns[i]->url, url) == 0)
        {ans= dns[i]->ip;
        break;}
  }
  pthread_mutex_unlock(&Mutex);
  return ans;
}

void pushdns(dns_t *dnsrecord){

  pthread_mutex_lock(&Mutex);
  for (int i = 0; i < DNS_RECORD_SIZE; i++)
  {
    if (!dns[i])
    {
      dns[i] = dnsrecord;
      break;
    }
  }
  pthread_mutex_unlock(&Mutex);
}

void error(char *msg){
  perror(msg);
  exit(1);
}

int sockfd;

void * handler( void * arg ){

  
   args *data= ( args *) arg;

   data->buffer[strlen(data->buffer)]='\0';

  printf("Received URL -> %s\n ", data->buffer);
  
  socklen_t clientlen = sizeof(data->address);
  int n;

  char *ip = search(data->buffer);

  if(ip!=NULL){
    
    printf("Found IP: %s for URL: %s\n", ip, data->buffer);
    int n=sendto(sockfd, data->buffer, strlen(data->buffer), 0, (struct sockaddr *)& data->address, clientlen);
    if (n < 0)
      error("[-] Error on sending\n");


  }else{


    //call higher DNS server;
    char temp[BUFFER_SIZE];
    strcpy(temp, data->buffer);
    char * ptr=strtok(temp, ".");
    char *domainName =   strtok(NULL, "."); ; //get the domain name 
    char *TLDomain =  strtok(NULL, "\n"); //get the TLDomain
    printf("Domain Name: %s , TLDomain: %s\n", domainName, TLDomain);

    char ipp[50];

    if(strcmp(TLDomain,"com")==0){

      printf("Calling com DNS server\n");
      struct sockaddr_in comserveraddr;
      comserveraddr.sin_port=htons(COM_PORT);
      comserveraddr.sin_family=AF_INET;
      comserveraddr.sin_addr.s_addr=inet_addr("127.0.0.1");
      int n=sendto(sockfd, data->buffer, strlen(data->buffer), 0, (struct sockaddr *)& comserveraddr, sizeof(comserveraddr));
      if (n < 0)
        error("[-] Error on sending\n");

      socklen_t len= sizeof(comserveraddr);
      n=recvfrom(sockfd,ipp, 50, 0,(struct sockaddr *)& comserveraddr, &len);
      printf("Recieved from TLD domain %s\n",ipp);

    }else if (strcmp(TLDomain,"org")==0){

       printf("Calling org DNS server\n");
      struct sockaddr_in orgserver;
      orgserver.sin_port=htons(ORG_PORT);
      orgserver.sin_family=AF_INET;
      orgserver.sin_addr.s_addr=inet_addr("127.0.0.1");
      int n=sendto(sockfd, data->buffer, strlen(data->buffer), 0, (struct sockaddr *)& orgserver, sizeof(orgserver));
      if (n < 0)
        error("[-] Error on sending\n");

      socklen_t len= sizeof(orgserver);
      n=recvfrom(sockfd,ipp, 50, 0,(struct sockaddr *)& orgserver, &len);
      printf("Recieved from TLD domain %s\n",ipp);  

    }

    int x=sendto(sockfd, ipp, strlen(ipp), 0, (struct sockaddr *)& data->address, clientlen);

    dns_t *dnsrecord = malloc(sizeof(dns_t));
      strcpy(dnsrecord->url, data->buffer);
      strcpy(dnsrecord->ip, ipp);
      pushdns(dnsrecord);

  }

  pthread_detach(pthread_self());
}



int main(){

  
  struct sockaddr_in serveraddr, clientaddr;


  sockfd = socket(AF_INET, SOCK_DGRAM, 0);
  if (sockfd < 0)
    error("Error opening socket");

  serveraddr.sin_port=htons(PORT);
  serveraddr.sin_family=AF_INET;
  serveraddr.sin_addr.s_addr=INADDR_ANY;

  if (bind(sockfd, (struct sockaddr*)&serveraddr, sizeof(serveraddr)) < 0)
    error("Error on binding");




char buffer[BUFFER_SIZE];

printf("Root DNS Server Running\n");
int n;

 while (1){

    socklen_t clientlen = sizeof(clientaddr);

  while ((n = recvfrom(sockfd, buffer, BUFFER_SIZE, 0, (struct sockaddr*)&clientaddr, &clientlen)) < 0) {
  }

  buffer[strlen(buffer)]='\0';

  args *arg = malloc(sizeof(args));
  strcpy(arg->buffer , buffer);
  arg->address = clientaddr;


  clientCount++;

  if (clientCount + 1 == MAX_CLIENTS) {
    printf("Max clients reached. Waiting for others to finish...\n");
    break;
  }

  pthread_t th;
  pthread_create(&th, NULL, &handler, arg);
  sleep(1);
}
  
// close(sockfd);

  return 0;
}
