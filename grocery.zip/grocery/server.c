#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <unistd.h>


#define PORT 5555
#define IP "127.0.0.1"

#define BUFFER_SIZE 1024
#define NAME_SIZE 32
#define MAX_CLIENT 5


static _Atomic unsigned int clientCount = 0;
static _Atomic unsigned int terminator = 0;
static int cid = 0;

struct sockaddr_in serveraddr;
int sockfd;

typedef struct{
  int sockfd;
  int ID;
  struct sockaddr_in address;
  char name[NAME_SIZE];
}client_t;


typedef struct{
  char name[NAME_SIZE];
  int price;
  int quantity;
}stock_t;

stock_t* stocks[50];

pthread_mutex_t stockmutex = PTHREAD_MUTEX_INITIALIZER;

void addItem (char * name , int price , int quantity){
  pthread_mutex_lock(&stockmutex);

  stock_t * itm = (stock_t *)malloc(sizeof(stock_t));
  strcpy(itm->name,name);
  itm->price = price;
  itm->quantity = quantity;

  for(int i= 0; i<10;i++){
    if(stocks[i]!=NULL){
      if(strcmp(stocks[i]->name, name)==0)
      {
        stocks[i]->price = price;
        stocks[i]->quantity = quantity;
        pthread_mutex_unlock(&stockmutex);
        return;
      }
      break;
    }
  }


 for(int i= 0; i<10;i++){
    if(stocks[i]==NULL){
      stocks[i]=itm;
      break;
    }
  }

  pthread_mutex_unlock(&stockmutex);
}




client_t* clients[MAX_CLIENT];

pthread_mutex_t Mutex = PTHREAD_MUTEX_INITIALIZER;

void error(char *msg){
  perror(msg);
  exit(1);
}

void pushClient(client_t *cl){
  pthread_mutex_lock(&Mutex);
  for (int i = 0; i < MAX_CLIENT; i++)
  {
    if(clients[i]==NULL){
      clients[i]=cl;
      break;
    }
  }
  pthread_mutex_unlock(&Mutex);
}


void removeClient(int id){
  pthread_mutex_lock(&Mutex);
  for (int i = 0; i < MAX_CLIENT; i++)
  {
    if(clients[i]){
      if(clients[i]->ID==id){
        clients[i]=NULL;
        break;
      }
    }
  }
  pthread_mutex_unlock(&Mutex);
}

int buy(char * name, int qty){

  pthread_mutex_lock(&stockmutex);

  for (int i = 0; i < 10; i++)
  {
    if(stocks[i]!=NULL){
      if(strcmp(stocks[i]->name,name)==0){
        if(stocks[i]->quantity>=qty){
          stocks[i]->quantity-=qty;
          pthread_mutex_unlock(&stockmutex);
          return stocks[i]->price*qty;
        }
        else{
          pthread_mutex_unlock(&stockmutex);
          return -1;
        }
      }
    }
  }
  

  pthread_mutex_unlock(&stockmutex);
  return -1;
}



void * showstatus(){

  printf("Item\tPrice\tQuantity\n");
  for (int i = 0; i < 10; i++)
  {
    if(stocks[i]!=NULL){
      printf("%s\t%d\t%d\n",stocks[i]->name,stocks[i]->price,stocks[i]->quantity);
    }
  }
  // sleep(5);
}





void * handleClient(void *arg){

  client_t * cl =(client_t *)arg;

  char buffer[BUFFER_SIZE];
  char name[NAME_SIZE];

  clientCount++;

  recv(cl->sockfd,name,NAME_SIZE,0);
  printf("%s has slide in to the chat\n", name);

  strcpy(cl->name,name);

  pushClient(cl);

  int sum=0;

  char ans[BUFFER_SIZE];

  while(1){

    bzero(buffer,BUFFER_SIZE);
    int receive = recv(cl->sockfd,buffer,BUFFER_SIZE,0);
    printf("%s: %s",cl->name,buffer);


    if(strstr(buffer, "end") != NULL){
      sprintf(ans,"That will be a total of %d $", sum);
      printf("%s: %s",cl->name,ans);
      send(cl->sockfd, ans, strlen(ans),0);
     printf("Hello\n");
      break;
    }
    else{

      char *temp = strtok(buffer," ");
      char *item = temp;

      temp = strtok(NULL," ");
      int qty = atoi(temp);

      int price = buy(item,qty);
      if(price<0){
        sprintf(ans,"Sorry, we don't have enough %s",item);
        send(cl->sockfd, ans, strlen(ans),0);
      }
      else{
        sum+=price;
      }


    }

    fflush(stdout);
    fflush(stdin);


  }

    removeClient(cl->ID);
    close(cl->sockfd);
    clientCount--;
    pthread_detach(pthread_self());
}

void * handleStock(){




}

int main(){

  sockfd = socket(AF_INET , SOCK_STREAM , 0);

  serveraddr.sin_port = htons(PORT);
  serveraddr.sin_family = AF_INET;
  serveraddr.sin_addr.s_addr = inet_addr(IP);

  socklen_t servlen = sizeof(serveraddr);
  if(bind(sockfd, (struct sockaddr *)&serveraddr,servlen)){
    error("bind");
  }

  if(listen(sockfd,MAX_CLIENT)){
    error("listen");
  }

  char buffer[BUFFER_SIZE];

  printf("Server started\n");


  addItem("apple", 10, 100);
  addItem("banana", 20, 100);
  addItem("orange", 30, 100);
  addItem("mango", 40, 100);
  addItem("grapes", 50, 100);
  addItem("pineapple", 60, 100);


  // pthread_t statust;
  // pthread_create(&statust, NULL , (void *)showstatus , NULL);
  

  while(1){

    struct sockaddr_in clientaddr;
    int clientfd= accept(sockfd , (struct sockaddr *)&clientaddr, &servlen);

    if(clientCount+1==MAX_CLIENT){
      printf("Max client reached. Rejected: ");
      printf("%s:%d\n",inet_ntoa(clientaddr.sin_addr),ntohs(clientaddr.sin_port));
      close(clientfd);
      continue;
    }
    client_t *cl = (client_t *)malloc(sizeof(client_t));

    cl->ID= cid++;
    cl->sockfd = clientfd;
    cl->address = clientaddr;

    pthread_t th;

    pthread_create(&th, NULL , (void *)handleClient , (void *)cl);

  }

  close(sockfd);
  return 0;
}

