#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <pthread.h>
#include <arpa/inet.h>
#include <signal.h>

#define PORT 5555
#define NAME_SIZE 30
#define BUFFER_SIZE 500
#define MESSAGE_SIZE 600

int sockfd;
struct sockaddr_in serverAddr;
char name[NAME_SIZE];
volatile _Atomic int  flag=0;

void error(char *msg){
  perror(msg);
  exit(1);
}

void cntrlC(int sig){
  flag=1;
}

void * readmsg(){
  char msg[MESSAGE_SIZE];

  while(!flag){
    bzero(msg, MESSAGE_SIZE);
    int n=recv(sockfd, msg, MESSAGE_SIZE, 0);
    if(n<0)
      error("[-] Error in receiving \n");

    msg[strlen(msg)]='\0';

    if((strstr(msg, "total"))!=NULL){
      printf("Thank You \n");
      flag=1;
      break;

    }

    fflush(stdout);
    printf("%s \n", msg);  
    bzero(msg, MESSAGE_SIZE);
  }
}

void * writemsg(){
  char buffer[BUFFER_SIZE];
  char msg[MESSAGE_SIZE];

  while(!flag){
    bzero(buffer, BUFFER_SIZE);
    printf("\r%s : " , name);
    fflush(stdout);
    fflush(stdin);
    fgets(buffer, BUFFER_SIZE, stdin);
    buffer[strlen(buffer)]='\0';
    if(send(sockfd, buffer, strlen(buffer), 0)<0)
      break;

    if(strstr(buffer, "end")!=NULL){
      flag=1;
      break;
    }

    }
  
  sleep(2);
  flag=1;
}

int main(){

  sockfd=socket(AF_INET, SOCK_STREAM, 0);
  if(sockfd<0)
    error("[-] Error in socket creation\n");


  //this signal handler is for the client to exit gracefully , when the client presses ctrl+c
  //cntrlc is a software interrupt
  signal(SIGINT, cntrlC);

  printf("Enter your name: ");
  fgets(name, NAME_SIZE, stdin);
  name[strlen(name)-1]='\0';

  memset(&serverAddr, '\0', sizeof(serverAddr));
  serverAddr.sin_family=AF_INET;
  serverAddr.sin_port=htons(PORT);
  serverAddr.sin_addr.s_addr=inet_addr("127.0.0.1");

  if(connect(sockfd, (struct sockaddr*)&serverAddr, sizeof(serverAddr))<0)
    error("[-] Error in connection\n");


  send(sockfd, name, strlen(name), 0);

  printf("======WELCOME TO THE Grocery Store======\n");

  pthread_t read_t, write_t;

  pthread_create(&write_t, NULL,(void *) writemsg, NULL);
  pthread_create(&read_t, NULL, (void *)readmsg, NULL);

  // while(1){
  //   if(flag){
  //     printf("[-] Exiting ip: %s port :%d", inet_ntoa(serverAddr.sin_addr), ntohs(serverAddr.sin_port));
  //     break;
  //   }
  // }

pthread_join(read_t, NULL);
pthread_join(write_t, NULL);


      close(sockfd);

  return 0;

}
